# Kinematics variables
L1 = 0.09+0.035   # head height (base ~ head center) (m)
L2 = 0.1340       # upper arm length (m)
L3 = 0.08+0.0525  # lower arm length (m)
